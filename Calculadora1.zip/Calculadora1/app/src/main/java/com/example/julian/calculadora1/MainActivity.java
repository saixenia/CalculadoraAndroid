package com.example.julian.calculadora1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText pantalla;
    private Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0, btnPunto, btnRaiz,
            btnElevadoaX, btnSeno, btnTangente, btnPi, btnElevadoCuadrado, btnC, btnCoseno, btnEuler, btnIgual, btnSuma, btnResta, btnMultiplicacion, btnFactorial,btnBase10,btnBorraPosicion;
    public double num1, num2, total;
    public int operacion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pantalla = (EditText) findViewById(R.id.pantalla);
        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btnPunto = (Button) findViewById(R.id.btnPunto);
        btnIgual = (Button) findViewById(R.id.btnIgual);
        btnRaiz = (Button) findViewById(R.id.btnRaiz);
        btnElevadoaX = (Button) findViewById(R.id.btnElevadoaX);
        btnSeno = (Button) findViewById(R.id.btnSeno);
        btnTangente = (Button) findViewById(R.id.btnTangente);
        btnPi = (Button) findViewById(R.id.btnPi);
        btnElevadoCuadrado = (Button) findViewById(R.id.btnElevadoCuadrado);
        btnC = (Button) findViewById(R.id.btnC);
        btnCoseno = (Button) findViewById(R.id.btnCoseno);
        btnEuler = (Button) findViewById(R.id.btnEuler);
        btnIgual = (Button) findViewById(R.id.btnIgual);
        btnSuma = (Button) findViewById(R.id.btnSuma);
        btnResta = (Button) findViewById(R.id.btnResta);
        btnMultiplicacion = (Button) findViewById(R.id.btnMultiplicacion);
    }

    public void btn1(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "1";
        pantalla.setText(numeroIngresado);

    }

    public void btn2(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "2";
        pantalla.setText(numeroIngresado);
    }

    public void btn3(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "3";
        pantalla.setText(numeroIngresado);
    }

    public void btn4(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "4";
        pantalla.setText(numeroIngresado);
    }

    public void btn5(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "5";
        pantalla.setText(numeroIngresado);
    }

    public void btn6(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "6";
        pantalla.setText(numeroIngresado);
    }

    public void btn7(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "7";
        pantalla.setText(numeroIngresado);
    }

    public void btn8(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "8";
        pantalla.setText(numeroIngresado);
    }

    public void btn9(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "9";
        pantalla.setText(numeroIngresado);
    }

    public void btn0(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + "0";
        pantalla.setText(numeroIngresado);
    }

    public void btnPunto(View v) {
        String numeroIngresado = pantalla.getText().toString();
        numeroIngresado = numeroIngresado + ".";
        pantalla.setText(numeroIngresado);
    }

    public void btnRaiz(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        ;
        pantalla.setText("√(" + num1 + ")");
        operacion = 1;

    }

    public void btnTangente(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        ;
        pantalla.setText("Tan (" + num1 + ")");
        operacion = 2;
    }

    public void btnC(View v) {
        pantalla.setText(null);
        num1 = 0.0;
        num2 = 0.0;
        total = 0.0;
    }

    public void btnDivision(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        ;
        pantalla.setText(null);
        operacion = 3;
    }

    public void btnElevadoaX(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }

        pantalla.setText(null);
        operacion = 4;
    }

    public void btnPi(View v) {
        num1 = Math.PI;
        pantalla.setText("" + num1);
    }

    public void btnCoseno(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        pantalla.setText("Cos (" + num1 + ")");
        operacion = 5;
    }

    public void btnSuma(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        pantalla.setText(null);
        operacion = 6;
    }

    public void btnSeno(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        pantalla.setText("Sin (" + num1 + ")");
        operacion = 7;
    }

    public void btnElevadoCuadrado(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        pantalla.setText(null);
        num1 = Math.pow(num1, 2);
        pantalla.setText("" + num1);

    }

    public void btnEuler(View v) {
        num1 = Math.E;
        pantalla.setText("" + num1);
    }

    public void btnResta(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        pantalla.setText(null);
        operacion = 9;
    }

    public void btnMultiplicacion(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        pantalla.setText(null);
        operacion = 10;
    }

    public void btnFactorial(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }
        total = 1;
        for (double i = num1; i >= 1; i--) {
            total = total * i;
        }
        pantalla.setText(""+total);
    }
    public void btnBase10(View v) {
        try {
            num1 = Double.parseDouble(pantalla.getText().toString());

        } catch (NumberFormatException nfe) {
        }

        pantalla.setText("10^("+num1+")");
        operacion =11 ;
    }
public void btnBorraPosicion(View v){
    if (!pantalla.getText().toString().equals("")) {
        pantalla.setText(pantalla.getText().subSequence(0, pantalla.getText().length()-1)+"");
    }

}
    public void btnIgual(View v) {

        switch (operacion) {
            case 1:
                total = Math.sqrt(num1);
                pantalla.setText("" + total);
                num1 = total;
                break;
            case 2:
                double Radianes1 = Math.toRadians(num1);
                total = (Math.tan(Radianes1));
                pantalla.setText("" + total);
                num1 = total;
                break;
            case 3:
                num2 = Double.parseDouble(pantalla.getText().toString());
                pantalla.setText(null);
                if (num2 == 0) {
                    pantalla.setText("Inderteminado");
                } else {
                    total = num1 / num2;
                    pantalla.setText("" + total);
                    num1 = total;
                    break;
                }
            case 4:
                total = Math.pow(num1, Double.parseDouble(pantalla.getText().toString()));
                pantalla.setText("" + total);
                break;
            case 5:
                double Radianes = Math.toRadians(num1);
                total = (Math.cos(Radianes));
                pantalla.setText("" + total);
                break;
            case 6:
                num2 = Double.parseDouble(pantalla.getText().toString());
                total = num1 + num2;
                pantalla.setText("" + total);
                num1 = total;
                break;
            case 7:
                Radianes = Math.toRadians(num1);
                total = (Math.sin(Radianes));
                pantalla.setText("" + total);
                break;
            case 8:
                num1 = Math.pow(num1, 2);
                pantalla.setText("" + num1);
                break;
            case 9:
                num2 = Double.parseDouble(pantalla.getText().toString());
                total = num1 - num2;
                pantalla.setText("" + total);
                num1 = total;
                break;
            case 10:
                num2 = Double.parseDouble(pantalla.getText().toString());
                total = num1 * num2;
                pantalla.setText("" + total);
                num1 = total;
                break;
            case 11:
                total = Math.pow(10,num1);
                pantalla.setText("" + total);
            default:
                pantalla.setText(pantalla.getText().toString());
                break;

        }
    }
}

